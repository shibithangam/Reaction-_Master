<?php
echo "<html>\n";
echo "<body>\n";

$ion = array(
    array(
        'ionname',
        'formula',
        'Rid',
    ),
);
include 'mysql.php';