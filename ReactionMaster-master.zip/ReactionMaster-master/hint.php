<?php
echo "<html>\n";
echo "<body>\n";

$hint = array(
    array(
        'Hid',
        'wordequation',
        'symbolicrepresentation',
        'Rid',
        
    ),
    
);
include 'mysql.php';
