<?php
error_reporting(0);
?>
<html>
<head>
<meta charset="UTF-8">
<title>Reaction Master Home Page</title>
<link href="css/default.css" rel="stylesheet">
</head>
<body>
<body background="C:\Users\kavya\Downloads\image 2.jpg">
</body>
<span>Home</span>