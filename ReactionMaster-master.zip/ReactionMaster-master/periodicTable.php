<?php
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
<img src="C:\Users\kavya\OneDrive\Desktop\Course work" height="200" width="200">