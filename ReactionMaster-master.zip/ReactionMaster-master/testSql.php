<?php
error_reporting(0);
?>

<?php
include 'mysql.php';
$res = retrieve();
echo $res;
?>