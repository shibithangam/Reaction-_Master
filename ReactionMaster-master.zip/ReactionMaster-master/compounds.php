<?php
echo "<html>\n";
echo "<body>\n";

$compounds = array(
    array(
       
        'Rid',
        'product',
        
    ),
);
include 'mysql.php';