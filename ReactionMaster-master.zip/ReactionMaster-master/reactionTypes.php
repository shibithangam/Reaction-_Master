<?php
echo "<html>\n";
echo "<body>\n";

$reactionTypes = array(
    array(
        
        'Tid' ,
        'combination' ,
        'decomposition' ,
        'singlereplacement',
        'doublereplacement',
        'oxygenreactions',
        'waterreactions',
        'acidbase',
        'complextion',
        'oxidationreduction',
        'Rid',
        
    ),
    
);
include 'mysql.php';
