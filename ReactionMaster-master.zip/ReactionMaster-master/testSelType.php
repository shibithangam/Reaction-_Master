<?php
error_reporting(0);
?>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Select Type Of Reactions For Test</title>
<p align="right">
<a href="logout.php">
<font size= "5" >Log Out</font>
</a>
</p>
<link href="css/Refined.css" rel="stylesheet">
</head>
<body>
<h1>Types of Reactions</h1>
<div style="overflow-x:auto;">
</div>
<br>
<br>
<p align="center">
<a href = "testPage.php" >
<font size="5">Combination</font>
</a>
</p>
<p align="center">
<a href = "decomTest.php" >
<font size="5">Decomposition</font>
</a>
</p>
<p align="center">
<a href = "singleRepTest.php" >
<font size="5">Single Replacement</font>
</a>
</p>
<p align="center">
<a href = "abcd.php" >
<font size="5">Double replacement</font>
</a>
</p>
<p align="center">
<a href = "oxygenTest.php" >
<font size="5">Oxygen Reactions</font>
</a>
</p>
<p align="center">
<a href = "waterTest.php" >
<font size="5">Water Reactions</font>
</a>
</p>
<p align="center">
<a href = "acidBaseTest.php" >
<font size="5">Acid-Base Reactions</font>
</a>
</p>
<p align="center">
<a href = "complexIonTest.php" >
<font size="5">Complex Ion Reactions</font>
</a>
</p>
<p align="center">
<a href = "oxiRedTest.php" >
<font size="5">Oxidation-Reduction Reactions</font>
</a>
</p>
